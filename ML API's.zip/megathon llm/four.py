from flask import Flask, request, jsonify
import pandas as pd
from fuzzywuzzy import fuzz

app = Flask(__name__)

# Predefined list of keywords related to mental health concerns
mental_health_keywords = [
    'acceptance', 'achieving dreams', 'anxiety', 'anxiety attacks', 
    'building confidence', 'burnout', "can't sleep well", 'career change', 
    'change', 'communication issues', 'confused about job prospects', 
    'confusion', 'constantly worried', 'coping mechanisms', 
    'coping strategies', 'coping with change', 'decision-making', 
    'depression', 'dissatisfaction', 'embracing change', 
    'emotional baggage', 'emotional intelligence', 'emotional regulation', 
    'emotional resilience', 'emotional support', 'emotional turmoil', 
    'expectations', 'exploring options', 'extremely stressed', 
    'fear of failure', 'fear of rejection', 'fear of success', 
    'fear of the unknown', 'feeling hopeful', 'feeling lost', 
    'feeling much better', 'feeling very anxious', 'feeling very low', 
    'financial concerns', 'finding purpose', 'following passions', 
    'goal setting', 'grounding techniques', 'happy and excited', 
    'health concerns', 'healthy boundaries', 'hopelessness', 
    'imposter syndrome', 'independence', 'isolation', 'job loss', 
    'journaling', 'life challenges', 'life changes', 'life goals', 
    'life transitions', 'lifestyle changes', 'managing emotions', 
    'mental clarity', 'mental exhaustion', 'mental health days', 
    'mental well-being', 'mindfulness', 'miscommunication', 
    'motivation', 'motivational struggles', 'navigating stress', 
    'negative thoughts', 'not eating properly', 'overwhelm', 
    'panic', 'personal growth', 'personal obstacles', 
    'personal values', 'positive affirmations', 'pressure', 
    'prioritizing happiness', 'prioritizing self-care', 
    'professional help', 'purpose', 'relationship issues', 
    'resilience', 'seeking clarity', 'seeking fulfillment', 
    'seeking help', 'seeking joy', 'self-acceptance', 
    'self-awareness', 'self-compassion', 'self-discovery', 
    'self-doubt', 'self-esteem', 'self-identity', 'self-reflection', 
    'setting goals', 'social anxiety', 'stability', 'stress', 
    'support groups', 'support networks', 'support system', 
    'therapy', 'transitioning careers', 'trust issues', 
    'uncertainty', 'work-life balance', 'work-related stress', 
    'worried about health', 'worry', "joy", "anger", "sadness", 
    "fear", "disgust", "surprise", "anticipation", "trust", 
    "love", "happiness", "contentment", "excitement", 
    "anxiety", "frustration", "relief", "embarrassment", 
    "shame", "guilt", "hope", "despair", "confusion", 
    "boredom", "loneliness", "jealousy", "envy", "pride", 
    "shyness", "compassion", "sympathy", "grief", 
    "nostalgia", "surprise", "curiosity", "trust", 
    "vulnerability", "apprehension", "disappointment", 
    "contentment", "enthusiasm", "determination", "euphoria", 
    "melancholy", "satisfaction", "insecurity", "indifference", 
    "defiance", "rage", "resentment", "self-pity", 
    "ambivalence", "courage", "passion", "eagerness", 
    "tenderness", "longing", "restlessness", "indecision", 
    "embarrassment", "assertiveness", "hopefulness", 
    "eagerness", "contentment", "dread", "warmth", 
    "solitude", "disillusionment", "fascination", "calmness", 
    "serenity", "gratefulness", "horror", "suffering", 
    "exhaustion", "revulsion", "appreciation", "yearning", 
    "self-confidence", "overwhelm", "zest", "empowerment", 
    "doubt", "reluctance", "cynicism", "hopefulness", 
    "helplessness", "perseverance", "restoration", 
    "clarity", "infatuation", "rebellion",
]
stop_words = set([
    'i', 'me', 'my', 'myself', 'we', 'our', 'ours', 'ourselves', 'you', 
    'your', 'yours', 'yourself', 'yourselves', 'he', 'him', 'his', 
    'himself', 'she', 'her', 'hers', 'herself', 'it', 'its', 'itself', 
    'they', 'them', 'their', 'theirs', 'themselves', 'what', 'which', 
    'who', 'whom', 'this', 'that', 'these', 'those', 'am', 'is', 'are', 
    'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had', 'having', 
    'do', 'does', 'did', 'doing', 'a', 'an', 'the', 'and', 'but', 
    'if', 'or', 'because', 'as', 'until', 'while', 'of', 'at', 'by', 
    'for', 'with', 'about', 'against', 'between', 'into', 'through', 
    'during', 'before', 'after', 'above', 'below', 'to', 'from', 
    'up', 'down', 'in', 'out', 'on', 'off', 'over', 'under', 'again', 
    'further', 'then', 'once', 'here', 'there', 'when', 'where', 
    'why', 'how', 'all', 'any', 'both', 'each', 'few', 'more', 
    'most', 'other', 'some', 'such', 'no', 'nor', 'not', 'only', 
    'own', 'same', 'so', 'than', 'too', 'very', 's', 't', 'can', 
    'will', 'just', 'don', 'should', 'now'
])


# Keyword to category mapping
keyword_to_category = {
    'anxiety': 'Anxiety Disorders',
    'social anxiety': 'Anxiety Disorders',
    'panic attacks': 'Anxiety Disorders',
    'phobias': 'Anxiety Disorders',
    'generalized anxiety': 'Anxiety Disorders',
    'depression': 'Mood Disorders',
    'bipolar disorder': 'Mood Disorders',
    'dysthymia': 'Mood Disorders',
    'sadness': 'Mood Disorders',
    'emotional instability': 'Mood Disorders',
    'burnout': 'Stress Management',
    'work-related stress': 'Stress Management',
    'chronic stress': 'Stress Management',
    'overwhelm': 'Stress Management',
    'stress': 'Stress Management',
    'coping strategies': 'Coping Mechanisms',
    'stress relief': 'Coping Mechanisms',
    'mindfulness': 'Coping Mechanisms',
    'relaxation techniques': 'Coping Mechanisms',
    'grounding techniques': 'Coping Mechanisms',
    'life changes': 'Life Transitions',
    'career change': 'Life Transitions',
    'relationship changes': 'Life Transitions',
    'transitions': 'Life Transitions',
    'identity crisis': 'Life Transitions',
    'personal growth': 'Personal Development',
    'self-esteem': 'Personal Development',
    'self-acceptance': 'Personal Development',
    'motivation': 'Personal Development',
    'goal setting': 'Personal Development',
    'emotional regulation': 'Emotional Health',
    'emotional support': 'Emotional Health',
    'emotional resilience': 'Emotional Health',
    'emotional intelligence': 'Emotional Health',
    'self-awareness': 'Emotional Health',
    'relationship issues': 'Relationship Concerns',
    'communication problems': 'Relationship Concerns',
    'trust issues': 'Relationship Concerns',
    'conflict resolution': 'Relationship Concerns',
    'codependency': 'Relationship Concerns',
    'addiction': 'Substance Use',
    'substance abuse': 'Substance Use',
    'alcoholism': 'Substance Use',
    'drug dependency': 'Substance Use',
    'rehabilitation': 'Substance Use',
    'mental health': 'General Mental Health',
    'mental well-being': 'General Mental Health',
    'self-care': 'General Mental Health',
    'support groups': 'General Mental Health',
    'professional help': 'General Mental Health',
    'fear': 'Emotional Concerns',
    'anger': 'Emotional Concerns',
    'sadness': 'Emotional Concerns',
    'guilt': 'Emotional Concerns',
    'shame': 'Emotional Concerns',
    'loneliness': 'Social Concerns',
    'isolation': 'Social Concerns',
    'fear of rejection': 'Social Concerns',
    'fear of failure': 'Social Concerns',
    'job loss': 'Financial Concerns',
    'financial concerns': 'Financial Concerns'
}

# Function to extract keywords from user input
def extract_keywords(user_input, threshold=60, limit=5):
    tokens = user_input.lower().split()
    filtered_tokens = [token for token in tokens if token not in stop_words]
    found_keywords = set()

    for keyword in mental_health_keywords:
        if keyword in filtered_tokens:
            found_keywords.add(keyword)
        else:
            if any(fuzz.partial_ratio(keyword, token) >= threshold for token in filtered_tokens):
                found_keywords.add(keyword)

    return list(found_keywords)[:limit]

# Function to classify concerns based on extracted keywords
def classify_concerns(keywords):
    classified_concerns = {}
    for keyword in keywords:
        category = keyword_to_category.get(keyword)
        if category:
            classified_concerns[keyword] = category
    return classified_concerns

# Function to score intensity based on keyword frequency
def score_intensity(classified_concerns):
    intensity_scores = {}
    for concern in classified_concerns.keys():
        intensity_scores[concern] = len(concern)  # Customize scoring logic as needed
    return intensity_scores

@app.route('/analyze', methods=['POST'])
def analyze():
    data = request.get_json()
    user_input = data.get('input', '')
    
    # Extract keywords
    extracted_keywords = extract_keywords(user_input, threshold=60, limit=5)
    
    # Classify concerns
    classified_concerns = classify_concerns(extracted_keywords)
    
    # Score intensity
    intensity_scores = score_intensity(classified_concerns)
    
    # Prepare response
    response = {
        "classified_concerns": classified_concerns,
        "intensity_scores": intensity_scores
    }
    
    return jsonify(response)

if __name__ == '__main__':
    app.run(debug=True, port=8085)