from flask import Flask, request, jsonify
import pandas as pd
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
import re

app = Flask(__name__)

# Initialize the VADER sentiment analyzer
analyzer = SentimentIntensityAnalyzer()

# Define the function to get polarity score using VADER
def get_vader_polarity(text):
    return analyzer.polarity_scores(text)['compound']

@app.route('/sentiment', methods=['POST'])
def analyze_sentiment():
    data = request.get_json()
    
    # Get the conversation data
    conversation_data = data.get('data', '')

    if conversation_data:
        # Process the conversation data into a structured format
        lines = conversation_data.strip().split('\n')
        user_inputs = [line for line in lines if line.startswith("User:")]

        # Extract only the user input text
        user_inputs_cleaned = [re.sub(r"^User: ", "", text).strip() for text in user_inputs]

        # Create a DataFrame from the user inputs
        df = pd.DataFrame({'User Input': user_inputs_cleaned})

        # Calculate and add polarity scores to a new column
        df['User_Input_Polarity'] = df['User Input'].apply(get_vader_polarity)

        # Save the DataFrame to a pickle file (optional, based on your requirement)
        df.to_pickle("polarity2.pkl")

        # Convert the DataFrame to a dictionary for the response
        response_data = df[['User Input', 'User_Input_Polarity']].to_dict(orient='records')

        return jsonify(response_data), 200
    else:
        return jsonify({'error': 'No data provided'}), 400

if __name__ == '__main__':
    app.run(debug=True, port = 5000)
