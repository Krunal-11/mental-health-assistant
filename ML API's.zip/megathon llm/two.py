from flask import Flask, request, jsonify, session
from langchain_ollama import OllamaLLM
from langchain_core.prompts import ChatPromptTemplate

app = Flask(__name__)
app.secret_key = "your_secret_key"  # Secret key for session management

# Define the improved prompt template
template = """
You are a supportive and empathetic assistant, here to listen and provide brief, comforting responses to help the user express their feelings. Your tone should be warm and conversational, like a friend who's listening attentively. Encourage the user to share more, but keep responses brief and natural, without mentioning any analysis or technical parameters. When you feel that the user is not providing any feelings for a few messages continuously, ask them with examples based on the conversation.

Here is the conversation history: {context}

Question: {question}

Response:
"""

# Initialize the model and prompt chain
model = OllamaLLM(model="llama3.2")
prompt = ChatPromptTemplate.from_template(template)
chain = prompt | model

@app.route('/output', methods=['POST'])
def main():
    # Retrieve user's input message from JSON request body
    user_input = request.json.get("message", "")
    
    # Retrieve or initialize the conversation context in session
    context = session.get("context", "")
    
    # Update context with user input
    context += f"\nUser: {user_input}"
    
    # Invoke the model with updated context and user input
    result = chain.invoke({"context": context, "question": user_input})
    formatted_response = result.strip()
    
    # Append the AI response to the context for continuity
    context += f"\nAI: {formatted_response}"
    
    # Store updated context in session for subsequent calls
    session["context"] = context
    
    # Send AI response back as JSON
    return jsonify({"response": formatted_response})

@app.route('/reset', methods=['POST'])
def reset_conversation():
    # Retrieve current context before resetting
    context = session.get("context", "")
    
    # Clear session context to start a new conversation
    session.pop("context", None)
    
    # Return the context along with a message
    return jsonify({"message": "Conversation reset.", "context": context})

if __name__ == "__main__":
    app.run(debug=True, port = 8081)
